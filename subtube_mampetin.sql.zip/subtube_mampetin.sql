-- phpMyAdmin SQL Dump
-- version 2.11.9.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 04, 2010 at 01:00 PM
-- Server version: 4.1.22
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `subtube_mampetin`
--

-- --------------------------------------------------------

--
-- Table structure for table `post_tweet`
--

DROP TABLE IF EXISTS `post_tweet`;
CREATE TABLE IF NOT EXISTS `post_tweet` (
  `TWT_USER_ID` varchar(200) collate utf8_unicode_ci NOT NULL default '',
  `TWT_SCREEN_NAME` varchar(200) collate utf8_unicode_ci NOT NULL default '',
  `TEXT` varchar(200) collate utf8_unicode_ci NOT NULL default '',
  `URL_SHORT_ID` int(11) NOT NULL default '0',
  `CREATE_TIMESTAMP` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`TWT_USER_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `post_tweet`
--


-- --------------------------------------------------------

--
-- Table structure for table `referrer`
--

DROP TABLE IF EXISTS `referrer`;
CREATE TABLE IF NOT EXISTS `referrer` (
  `REFERRER_ID` int(10) NOT NULL auto_increment,
  `URL_SHORT_ID` int(10) NOT NULL default '0',
  `IP_REQUEST` varchar(200) collate utf8_unicode_ci NOT NULL default '',
  `REFFERAL` text collate utf8_unicode_ci NOT NULL,
  `CREATE_TIMESTAMP` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`REFERRER_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=201 ;

--
-- Dumping data for table `referrer`
--

INSERT INTO `referrer` (`REFERRER_ID`, `URL_SHORT_ID`, `IP_REQUEST`, `REFFERAL`, `CREATE_TIMESTAMP`) VALUES
(16, 16, '111.94.21.77', 'http://subtu.be/index.php', '2010-02-23 14:31:59'),
(17, 18, '125.165.81.170', 'http://subtu.be/index.php', '2010-02-23 15:08:44'),
(18, 19, '114.59.48.252', 'http://subtu.be/index.php', '2010-02-23 16:17:33'),
(19, 21, '118.137.192.202', 'http://subtu.be/index.php', '2010-02-23 16:42:59'),
(20, 24, '114.56.95.167', 'http://subtu.be/8878f', '2010-02-24 13:05:41'),
(21, 31, '114.56.95.167', 'http://subtu.be/index.php', '2010-02-24 13:20:41'),
(22, 32, '114.56.95.167', 'http://subtu.be/index.php', '2010-02-24 13:30:24'),
(23, 35, '206.53.152.48', 'http://www.subtu.be/index.php', '2010-02-24 16:01:31'),
(24, 36, '174.143.213.49', 'http://twitturls.com/', '2010-02-24 16:04:14'),
(25, 38, '206.53.152.55', 'http://www.subtu.be/index.php', '2010-02-24 16:16:01'),
(26, 39, '206.53.152.55', 'http://www.subtu.be/index.php', '2010-02-24 16:16:31'),
(27, 36, '174.143.236.111', 'http://longurl.org', '2010-02-24 16:48:58'),
(28, 40, '125.161.142.94', 'http://twitter.com/donnieprakoso', '2010-02-24 18:54:22'),
(29, 40, '203.142.85.12', 'http://twitter.com/', '2010-02-25 00:36:43'),
(30, 40, '203.142.68.130', 'http://twitter.com/donnieprakoso', '2010-02-25 07:06:27'),
(31, 40, '203.142.68.130', 'http://twitter.com/donnieprakoso', '2010-02-25 07:06:55'),
(32, 43, '206.53.152.78', 'http://subtu.be/index.php', '2010-02-26 06:02:52'),
(33, 40, '114.56.76.204', 'http://twitter.com/donnieprakoso', '2010-02-26 09:12:23'),
(34, 44, '206.53.152.62', 'http://subtu.be/index.php', '2010-02-26 16:16:02'),
(35, 44, '118.137.192.202', 'http://twitter.com/', '2010-02-26 16:19:22'),
(36, 45, '206.53.152.76', 'http://subtu.be/index.php', '2010-02-27 00:27:16'),
(37, 46, '125.160.235.122', 'http://subtu.be/index.php', '2010-02-27 06:01:42'),
(38, 47, '125.160.235.122', 'http://subtu.be/index.php', '2010-02-27 06:02:03'),
(39, 48, '67.202.7.151', 'http://twitter.com', '2010-02-28 02:48:16'),
(40, 48, '110.138.93.205', 'http://www.facebook.com/adimir?ref=search&sid=652622606.315460821..1', '2010-02-28 03:01:32'),
(41, 48, '110.138.93.205', 'http://www.facebook.com/adimir?ref=search&sid=652622606.315460821..1', '2010-02-28 03:10:30'),
(42, 48, '110.138.93.205', 'http://www.facebook.com/adimir?ref=search&sid=652622606.315460821..1', '2010-02-28 03:11:18'),
(43, 52, '118.137.192.202', 'http://subtu.be/index.php', '2010-03-02 18:07:55'),
(44, 52, '114.58.184.220', 'http://twitter.com/', '2010-03-02 18:08:58'),
(45, 52, '118.137.192.202', 'http://twitter.com/', '2010-03-02 18:09:21'),
(46, 52, '125.163.23.63', 'http://twitter.com/', '2010-03-02 18:11:21'),
(47, 52, '125.166.163.43', 'http://twitter.com/', '2010-03-02 18:11:30'),
(48, 52, '114.58.184.47', 'http://twitter.com/', '2010-03-02 18:11:40'),
(49, 52, '114.199.97.38', 'http://twitter.com/', '2010-03-02 18:11:41'),
(50, 52, '118.136.212.117', 'http://dabr.co.uk/', '2010-03-02 18:12:05'),
(51, 52, '118.137.194.119', 'http://twitter.com/', '2010-03-02 18:12:37'),
(52, 52, '202.70.54.212', 'http://twitter.com/', '2010-03-02 18:12:48'),
(53, 52, '110.136.232.115', 'http://twitter.com/', '2010-03-02 18:12:53'),
(54, 52, '203.78.120.24', 'http://twitter.com/', '2010-03-02 18:13:02'),
(55, 52, '75.101.185.232', 'http://twitter.com', '2010-03-02 18:13:24'),
(56, 52, '202.93.37.113', 'http://twitter.com/?status=@Dee_my&in_reply_to_status_id=9882996072&in_reply_to=Dee_my', '2010-03-02 18:13:41'),
(57, 52, '118.136.249.248', 'http://twitter.com/', '2010-03-02 18:13:50'),
(58, 52, '118.136.106.25', 'http://twitter.com/', '2010-03-02 18:13:55'),
(59, 52, '118.137.192.202', 'http://twitter.com/', '2010-03-02 18:14:38'),
(60, 52, '110.76.148.50', 'http://twitter.com/', '2010-03-02 18:14:42'),
(61, 52, '118.96.45.251', 'http://twitter.com/', '2010-03-02 18:14:43'),
(62, 52, '202.184.124.19', 'http://twitter.com/', '2010-03-02 18:14:54'),
(63, 52, '72.44.42.113', 'http://twitter.com', '2010-03-02 18:15:38'),
(64, 52, '125.166.162.73', 'http://twitter.com/', '2010-03-02 18:15:42'),
(65, 52, '114.121.170.56', 'http://iconfactory.com/twitterrific', '2010-03-02 18:16:08'),
(66, 52, '120.163.184.192', 'http://twitter.com/', '2010-03-02 18:16:15'),
(67, 52, '125.165.143.2', 'http://twitter.com/csugiono', '2010-03-02 18:16:16'),
(68, 52, '124.82.138.98', 'http://twitter.com/', '2010-03-02 18:16:35'),
(69, 52, '125.164.64.3', 'http://twitter.com/', '2010-03-02 18:16:42'),
(70, 52, '82.113.121.248', 'http://twitter.com/', '2010-03-02 18:17:13'),
(71, 52, '118.96.148.91', 'http://twitter.com/', '2010-03-02 18:17:41'),
(72, 52, '202.3.213.130', 'http://twitter.com/home', '2010-03-02 18:19:09'),
(73, 52, '111.94.138.209', 'http://twitter.com/', '2010-03-02 18:19:10'),
(74, 52, '118.136.68.59', 'http://twitter.com/', '2010-03-02 18:20:53'),
(75, 52, '64.255.180.103', 'http://mobile.twitter.com/', '2010-03-02 18:20:57'),
(76, 52, '114.56.171.175', 'http://twitter.com/', '2010-03-02 18:22:08'),
(77, 52, '110.137.230.242', 'http://twitter.com/', '2010-03-02 18:22:16'),
(78, 52, '125.161.140.252', 'http://twitter.com/', '2010-03-02 18:22:22'),
(79, 52, '206.53.152.81', 'http://twitter.com/home', '2010-03-02 18:24:28'),
(80, 52, '120.163.198.163', 'http://twitter.com/', '2010-03-02 18:24:28'),
(81, 52, '110.137.73.253', 'http://twitter.com/', '2010-03-02 18:24:45'),
(82, 52, '64.255.180.31', 'http://mobile.twitter.com/?max_id=9884980513', '2010-03-02 18:33:07'),
(83, 52, '114.120.133.64', 'http://twitter.com/', '2010-03-02 18:36:28'),
(84, 52, '114.59.32.55', 'http://hootsuite.com/dashboard', '2010-03-02 18:44:50'),
(85, 52, '220.255.0.38', 'http://twitter.com/csugiono', '2010-03-02 18:55:02'),
(86, 52, '64.255.180.177', 'http://mobile.twitter.com/', '2010-03-02 19:01:52'),
(87, 52, '220.255.0.38', 'http://twitter.com/', '2010-03-02 19:02:11'),
(88, 52, '64.255.180.62', 'http://m.tweete.net/home?page=2', '2010-03-02 19:08:28'),
(89, 52, '64.255.180.215', 'http://mobile.twitter.com/?max_id=9885831332', '2010-03-02 19:46:51'),
(90, 52, '64.255.180.61', 'http://mobile.twitter.com/', '2010-03-02 20:21:22'),
(91, 52, '118.96.218.152', 'http://twitter.com/csugiono', '2010-03-02 20:34:27'),
(92, 52, '125.163.66.68', 'http://twitter.com/csugiono', '2010-03-02 20:36:40'),
(93, 52, '118.136.54.43', 'http://twitter.com/', '2010-03-02 21:17:19'),
(94, 52, '64.255.180.217', 'http://mobile.twitter.com/', '2010-03-02 21:36:20'),
(95, 52, '114.58.179.123', 'http://twitter.com/csugiono', '2010-03-02 21:52:24'),
(96, 52, '64.255.180.80', 'http://dabr.co.uk/user/MelissaCruel', '2010-03-02 22:04:11'),
(97, 52, '64.255.180.163', 'http://m.dabr.co.uk/', '2010-03-02 22:16:53'),
(98, 52, '64.255.180.202', 'http://mobile.twitter.com/?max_id=9886416423', '2010-03-02 23:02:47'),
(99, 52, '114.58.243.70', 'http://twitter.com/csugiono', '2010-03-02 23:11:37'),
(100, 52, '61.5.120.18', 'http://twitter.com/', '2010-03-02 23:26:36'),
(101, 52, '64.255.180.119', 'http://mobile.twitter.com/?max_id=9885752464', '2010-03-03 00:10:59'),
(102, 52, '125.160.213.75', 'http://twitter.com/csugiono', '2010-03-03 00:22:05'),
(103, 52, '125.166.183.174', 'http://twitter.com/csugiono', '2010-03-03 00:24:50'),
(104, 52, '64.255.180.53', 'http://mobile.twitter.com/?max_id=9885048438', '2010-03-03 00:45:07'),
(105, 52, '64.255.180.79', 'http://mobile.twitter.com/?max_id=9885462118', '2010-03-03 01:20:23'),
(106, 52, '118.136.92.183', 'http://twitter.com/', '2010-03-03 01:29:19'),
(107, 52, '125.161.219.192', 'http://twitter.com/csugiono', '2010-03-03 01:39:49'),
(108, 52, '111.94.153.240', 'http://twitter.com/csugiono', '2010-03-03 02:09:12'),
(109, 53, '118.137.192.202', 'http://subtu.be/index.php', '2010-03-03 02:14:39'),
(110, 53, '67.202.7.151', 'http://twitter.com', '2010-03-03 02:17:26'),
(111, 53, '118.137.192.202', 'http://twitter.com/', '2010-03-03 02:17:28'),
(112, 53, '118.137.192.202', 'http://twitter.com/', '2010-03-03 02:19:40'),
(113, 53, '180.214.234.2', 'http://www.netvibes.com/', '2010-03-03 02:20:21'),
(114, 52, '202.152.23.106', 'http://twitter.com/csugiono', '2010-03-03 02:24:34'),
(115, 52, '118.137.192.202', 'http://twitter.com/yyoyoma', '2010-03-03 02:27:24'),
(116, 52, '202.89.23.20', 'http://twitter.com/', '2010-03-03 02:29:24'),
(117, 52, '118.136.244.145', 'http://twitter.com/', '2010-03-03 02:31:31'),
(118, 52, '118.96.81.200', 'http://twitter.com/', '2010-03-03 02:31:57'),
(119, 53, '125.161.139.71', 'http://twitter.com/', '2010-03-03 02:35:10'),
(120, 52, '125.161.139.71', 'http://twitter.com/', '2010-03-03 02:35:25'),
(121, 52, '202.158.10.97', 'http://twitter.com/', '2010-03-03 02:37:26'),
(122, 52, '202.155.113.73', 'http://www.dabr.co.uk/', '2010-03-03 02:37:50'),
(123, 52, '202.152.231.130', 'http://twitter.com/', '2010-03-03 02:43:14'),
(124, 52, '206.53.152.96', 'http://twitter.com/', '2010-03-03 02:43:59'),
(125, 52, '118.137.200.83', 'http://twitter.com/', '2010-03-03 03:01:32'),
(126, 52, '206.53.152.41', 'http://m.twitter.com/?format=mobile&page=7&ref=getjar.com&vbuid=12640806171339649035', '2010-03-03 03:03:05'),
(127, 52, '211.233.79.177', 'http://subtu.be/', '2010-03-03 03:05:16'),
(128, 52, '64.255.180.72', 'http://beta.tweete.net/yyoyoma', '2010-03-03 03:07:08'),
(129, 52, '125.162.125.122', 'http://twitter.com/', '2010-03-03 03:13:20'),
(130, 52, '125.164.24.76', 'http://twitter.com/', '2010-03-03 03:36:46'),
(131, 52, '118.137.212.175', 'http://twitter.com/', '2010-03-03 03:39:05'),
(132, 52, '117.102.92.204', 'http://twitter.com/', '2010-03-03 03:43:29'),
(133, 52, '117.102.92.204', 'http://twitter.com/', '2010-03-03 04:01:33'),
(134, 52, '114.59.34.11', 'http://twitter.com/csugiono', '2010-03-03 04:05:39'),
(135, 52, '195.189.142.189', 'http://twitter.com/csugiono', '2010-03-03 04:06:27'),
(136, 52, '203.110.237.2', 'http://twitter.com/halief', '2010-03-03 04:16:16'),
(137, 52, '118.137.98.228', 'http://twitter.com/', '2010-03-03 04:32:43'),
(138, 52, '114.121.161.137', 'http://twitter.com/', '2010-03-03 04:37:40'),
(139, 52, '180.214.232.38', 'http://dabr.co.uk/?page=24', '2010-03-03 04:53:13'),
(140, 52, '192.172.226.121', 'http://twitter.com/', '2010-03-03 05:07:41'),
(141, 52, '61.247.48.8', 'http://twitter.com/', '2010-03-03 05:17:34'),
(142, 52, '99.167.93.124', 'http://twitter.com/home', '2010-03-03 05:59:27'),
(143, 52, '110.139.50.55', 'http://twitter.com/CSugiono', '2010-03-03 06:25:37'),
(144, 52, '61.247.5.83', 'http://twitter.com/csugiono', '2010-03-03 06:52:05'),
(145, 52, '125.160.76.227', 'http://twitter.com/csugiono', '2010-03-03 07:12:27'),
(146, 52, '125.163.74.135', 'http://twitter.com/', '2010-03-03 07:12:37'),
(147, 52, '203.148.85.145', 'http://twitter.com/csugiono', '2010-03-03 07:13:49'),
(148, 52, '118.96.158.155', 'http://twitter.com/csugiono', '2010-03-03 07:47:44'),
(149, 52, '222.124.196.171', 'http://twitter.com/csugiono', '2010-03-03 07:56:42'),
(150, 55, '202.70.59.181', 'http://sn129w.snt129.mail.live.com/mail/InboxLight.aspx?n=1078699410', '2010-03-03 08:11:25'),
(151, 55, '202.43.95.57', 'http://us.mc655.mail.yahoo.com/mc/welcome?.gx=1&.tm=1267580803&.rand=b7qg9onmu48be', '2010-03-03 08:20:53'),
(152, 55, '202.70.59.181', 'http://sn129w.snt129.mail.live.com/mail/InboxLight.aspx?FolderID=00000000-0000-0000-0000-000000000005&n=1489956515', '2010-03-03 08:22:29'),
(153, 55, '202.70.59.181', 'http://souvenirpernikahanku.com/wp-content/uploads/2009/10/mika.jpg', '2010-03-03 08:22:48'),
(154, 55, '202.43.95.57', 'http://souvenirpernikahanku.com/wp-content/uploads/2009/10/mika.jpg', '2010-03-03 08:31:07'),
(155, 40, '125.166.198.155', 'http://twitter.com/donnieprakoso', '2010-03-03 10:47:21'),
(156, 40, '125.166.198.155', 'http://twitter.com/donnieprakoso', '2010-03-03 10:47:32'),
(157, 52, '118.136.251.49', 'http://twitter.com/csugiono', '2010-03-03 10:50:52'),
(158, 52, '125.164.210.142', 'http://twitter.com/', '2010-03-03 11:10:02'),
(159, 52, '111.94.187.73', 'http://twitter.com/', '2010-03-03 11:56:56'),
(160, 52, '110.137.31.148', 'http://twitter.com/csugiono', '2010-03-03 12:46:39'),
(161, 52, '118.136.196.190', 'http://twitter.com/csugiono', '2010-03-03 13:19:28'),
(162, 52, '202.152.240.121', 'http://twitter.com/?format=mobile&page=18', '2010-03-03 13:39:18'),
(163, 52, '110.138.35.253', 'http://twitter.com/csugiono', '2010-03-03 14:23:54'),
(164, 52, '118.137.60.92', 'http://twitter.com/', '2010-03-03 15:18:29'),
(165, 52, '38.105.71.72', 'http://www.google.com/search?hl=en&source=hp&q=subtu.be/fa681&aq=f&oq=&aqi=', '2010-03-03 22:40:17'),
(166, 55, '202.43.95.57', 'http://us.mc655.mail.yahoo.com/mc/welcome?.gx=1&.tm=1267663228&.rand=0lqcudm140usj', '2010-03-04 00:58:27'),
(167, 52, '114.59.180.231', 'http://twitter.com/mangkum', '2010-03-04 01:02:50'),
(168, 52, '125.166.129.161', 'http://twitter.com/csugiono', '2010-03-04 01:37:15'),
(169, 40, '203.142.85.12', 'http://www.google.com/profiles/donnie.prakoso', '2010-03-04 03:34:20'),
(170, 52, '125.160.32.119', 'http://twitter.com/csugiono', '2010-03-04 04:26:24'),
(171, 57, '203.153.116.154', 'http://subtu.be/index.php', '2010-03-04 08:44:40'),
(172, 57, '75.101.185.232', 'http://twitter.com', '2010-03-04 08:45:15'),
(173, 52, '114.120.146.105', 'http://twitter.com/csugiono', '2010-03-04 09:40:12'),
(174, 58, '117.102.92.204', 'http://twitter.com/', '2010-03-04 10:15:10'),
(175, 58, '117.102.80.10', 'http://twitter.com/', '2010-03-04 10:15:59'),
(176, 58, '198.178.237.4', 'http://twitter.com/', '2010-03-04 10:17:51'),
(177, 58, '193.219.192.218', 'http://twitter.com/', '2010-03-04 10:18:35'),
(178, 58, '202.6.229.195', 'http://hootsuite.com/dashboard', '2010-03-04 10:19:19'),
(179, 58, '118.137.212.175', 'http://twitter.com/', '2010-03-04 10:20:26'),
(180, 58, '64.255.180.172', 'http://beta.tweete.net/home', '2010-03-04 10:20:41'),
(181, 58, '110.138.39.204', 'http://twitter.com/', '2010-03-04 10:21:25'),
(182, 58, '67.202.7.151', 'http://twitter.com', '2010-03-04 10:21:38'),
(183, 58, '202.3.213.130', 'http://m.twitter.com/home', '2010-03-04 10:23:13'),
(184, 58, '203.153.116.154', 'http://tub2tweet.subtube.com/home.php', '2010-03-04 10:24:25'),
(185, 58, '222.124.203.10', 'http://twitter.com/', '2010-03-04 10:26:41'),
(186, 58, '117.103.170.194', 'http://twitter.com/', '2010-03-04 10:26:51'),
(187, 58, '125.163.13.145', 'http://twitter.com/', '2010-03-04 10:27:00'),
(188, 58, '64.255.180.197', 'http://mobile.twitter.com/', '2010-03-04 10:27:43'),
(189, 58, '114.4.14.245', 'http://twitter.com/', '2010-03-04 10:28:03'),
(190, 58, '64.255.180.172', 'http://m.tweete.net/home', '2010-03-04 10:31:50'),
(191, 58, '125.163.9.165', 'http://twitter.com/', '2010-03-04 10:32:25'),
(192, 58, '220.255.0.48', 'http://iconfactory.com/twitterrific', '2010-03-04 10:55:06'),
(193, 58, '125.161.141.174', 'http://twitter.com/hasief', '2010-03-04 11:02:29'),
(194, 58, '118.137.17.69', 'http://twitter.com/', '2010-03-04 11:05:48'),
(195, 58, '118.136.203.13', 'http://twitter.com/alodita', '2010-03-04 11:24:33'),
(196, 58, '202.93.37.114', 'http://twitter.com/', '2010-03-04 11:42:48'),
(197, 58, '80.248.254.190', 'http://www.tumblr.com/tagged/Trololololololololololo', '2010-03-04 11:43:11'),
(198, 58, '220.255.0.48', 'http://twitter.com/', '2010-03-04 11:52:09'),
(199, 58, '64.255.180.105', 'http://mobile.twitter.com/?max_id=9967961820', '2010-03-04 12:02:20'),
(200, 58, '203.142.68.130', 'http://twitter.com/donnieprakoso/subtube', '2010-03-04 12:34:15');

-- --------------------------------------------------------

--
-- Table structure for table `url_short`
--

DROP TABLE IF EXISTS `url_short`;
CREATE TABLE IF NOT EXISTS `url_short` (
  `URL_SHORT_ID` int(10) NOT NULL auto_increment,
  `LONG_URL` text collate utf8_unicode_ci NOT NULL,
  `SHORT_URL` varchar(200) collate utf8_unicode_ci NOT NULL default '',
  `IP_REQUEST` varchar(200) collate utf8_unicode_ci default NULL,
  `HITS` int(10) NOT NULL default '0',
  `PROTECTED` int(1) NOT NULL default '0',
  `PROTECTED_KEY` varchar(20) collate utf8_unicode_ci default NULL,
  `CREATE_TIMESTAMP` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`URL_SHORT_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=59 ;

--
-- Dumping data for table `url_short`
--

INSERT INTO `url_short` (`URL_SHORT_ID`, `LONG_URL`, `SHORT_URL`, `IP_REQUEST`, `HITS`, `PROTECTED`, `PROTECTED_KEY`, `CREATE_TIMESTAMP`) VALUES
(16, 'http://www.detiknews.com/read/2010/02/23/212048/1305437/10/fraksi-partai-demokrat-minta-pansus-jangan-asal-fitnah?991101605', '0ba31', '111.94.21.77', 1, 0, NULL, '2010-02-23 14:31:50'),
(17, 'http://www.malesbanget.com', 'b05b9', '206.53.152.99', 0, 0, NULL, '2010-02-23 14:34:23'),
(18, 'http://new.myfonts.com/fonts/exljbris/museo/', 'f6a69', '125.165.81.170', 1, 0, NULL, '2010-02-23 15:08:39'),
(19, 'http://www.malesbanget.com', 'b67f0', '114.59.48.252', 1, 0, NULL, '2010-02-23 16:17:28'),
(20, 'http://www.engadget.com/2010/02/23/alienware-m11x-review/', '0530a', '118.137.192.202', 1, 0, NULL, '2010-02-23 16:40:36'),
(21, 'http://www.flickr.com/photos/strawman3125/2389736373/sizes/l/', 'a27ea', '118.137.192.202', 1, 0, NULL, '2010-02-23 16:42:23'),
(22, 'http://www.flickr.com/photos/aryosayogha/tags/ibookg4/', '88e21', '203.142.68.130', 5, 0, NULL, '2010-02-24 05:54:47'),
(23, 'http://www.malesbanget.com', '6e6bc', '114.56.95.167', 0, 1, 'tian', '2010-02-24 13:04:35'),
(24, 'http://www.malesbanget.com', '8878f', '114.56.95.167', 1, 1, 'tian', '2010-02-24 13:05:31'),
(25, 'URL to shorten', '653e1', '114.56.95.167', 0, 0, NULL, '2010-02-24 13:14:08'),
(26, 'URL to shorten', '858e3', '114.56.95.167', 0, 0, NULL, '2010-02-24 13:15:38'),
(27, 'URL to shorten', 'eb9e3', '114.56.95.167', 0, 0, NULL, '2010-02-24 13:17:42'),
(28, 'URL to shorten', '97f34', '114.56.95.167', 0, 0, NULL, '2010-02-24 13:18:28'),
(29, 'URL to shorten', 'd8747', '114.56.95.167', 0, 0, NULL, '2010-02-24 13:19:03'),
(30, 'URL to shorten', '1ce16', '114.56.95.167', 0, 0, NULL, '2010-02-24 13:20:00'),
(31, 'URL to shorten', '1a756', '114.56.95.167', 1, 0, NULL, '2010-02-24 13:20:30'),
(32, 'http://twitter.com/', 'd15e5', '114.56.95.167', 1, 0, NULL, '2010-02-24 13:30:17'),
(33, 'URL to shorten', 'bc393', '114.56.95.167', 0, 0, NULL, '2010-02-24 13:32:37'),
(34, 'URL to shorten', 'd7da3', '206.53.152.93', 0, 0, NULL, '2010-02-24 13:54:50'),
(35, 'http://www.malesbanget.com', '4e43b', '206.53.152.48', 1, 0, NULL, '2010-02-24 16:01:16'),
(36, 'http://www.urlesque.com/2010/02/19/epic-beard-man/', 'aef79', '118.137.192.202', 31, 0, NULL, '2010-02-24 16:02:35'),
(37, 'www.thingamajiggyouyou.com', 'c23c2', '206.53.152.55', 0, 0, NULL, '2010-02-24 16:15:30'),
(38, 'yahoo.com', '9b059', '206.53.152.55', 1, 0, NULL, '2010-02-24 16:15:52'),
(39, 'www.yahoo.com', '5afa0', '206.53.152.55', 1, 0, NULL, '2010-02-24 16:16:22'),
(40, 'http://www.belkin.com/IWCatProductPage.process?Product_Id=459917#', '23919', '125.161.142.94', 31, 0, NULL, '2010-02-24 18:53:29'),
(41, 'http://nicetry.me', 'cba61', '203.142.68.130', 1, 0, NULL, '2010-02-25 09:34:44'),
(42, 'http://subtu.be/cba61', 'e2f20', '203.142.68.129', 0, 0, NULL, '2010-02-25 09:35:00'),
(43, 'www.yahoo.com', '1fc7b', '206.53.152.78', 2, 0, NULL, '2010-02-26 06:02:41'),
(44, 'http://m.detik.com/read/2010/02/25/183129/1307085/317/6-blackberry-baru-siap-masuk-indonesia', 'ed584', '206.53.152.62', 12, 0, NULL, '2010-02-26 16:14:27'),
(45, 'URL to shorten', '5b65d', '206.53.152.76', 1, 0, NULL, '2010-02-27 00:26:44'),
(46, 'http', '24ef4', '125.160.235.122', 1, 0, NULL, '2010-02-27 06:01:27'),
(47, 'http://bit.ly', '285f7', '125.160.235.122', 1, 0, NULL, '2010-02-27 06:01:53'),
(48, 'http://blackberry.bosen.net/', 'b09b3', '111.94.21.77', 40, 0, NULL, '2010-02-28 02:47:38'),
(49, 'http://id.imediabiz.com/web-hosting-australia-indonesia/web-hosting-murah/dedicated-server-murah/business-hosting-murah-detail.php?id=B-10GB', 'e0f45', '203.142.68.129', 3, 0, NULL, '2010-03-01 08:56:25'),
(50, 'http://i48.tinypic.com/2dgqbmv.jpg', '1d5b9', '203.142.68.129', 3, 0, NULL, '2010-03-01 11:58:30'),
(51, 'http://greener-indonesia.com/images/splash-img.jpg', '69ef5', '203.142.68.129', 7, 0, NULL, '2010-03-02 13:14:45'),
(52, 'http://www.youtube.com/watch?v=yQ4On3R8Mjg&feature=player_embedded', 'fa681', '118.137.192.202', 447, 0, NULL, '2010-03-02 18:07:51'),
(53, 'http://dagdigdug.com/2010/03/02/aryo-sayogha-mendokumentasikan-indonesia-secara-cengengesan/', '565d5', '118.137.192.202', 55, 0, NULL, '2010-03-03 02:13:46'),
(54, 'http://nicetry.me/post/422366179/aksi-roy-suryo-di-sidang-pari-purna-via', '5de5d', '118.137.192.202', 0, 0, NULL, '2010-03-03 02:24:14'),
(55, 'http://souvenirpernikahanku.com/wp-content/uploads/2009/10/mika.jpg', 'f8599', '203.142.68.129', 22, 0, NULL, '2010-03-03 06:28:32'),
(56, 'URL to shorten', '2b2d1', '202.70.58.208', 0, 0, NULL, '2010-03-04 07:53:22'),
(57, 'http://www.wikihow.com/Exercise-While-Sitting-at-Your-Computer', '5c58d', '203.153.116.154', 32, 0, NULL, '2010-03-04 08:44:36'),
(58, 'http://yyoyoma.tumblr.com/post/426005391/trololololololololololo-lyric', '4da44', '203.142.68.129', 189, 0, NULL, '2010-03-04 10:12:17');
